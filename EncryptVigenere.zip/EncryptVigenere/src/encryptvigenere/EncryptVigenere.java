package encryptvigenere;
import java.io.IOException;
import java.util.Scanner;

public class EncryptVigenere {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws IOException {
        Scanner sc = new Scanner(System.in);
        Encryptor en = new Encryptor();
        System.out.println("Введите ключ и индекс смещения");
        en.alphabetcreate();
        System.out.println("Выберите действие: 1. Зашифровать; 2. Расшифровать;");
        int i = sc.nextInt();
        switch (i) {
            case 1:
                System.out.println("Введите текст для шифрования");
                System.out.println(en.encrypt());
                break;
            case 2:
                System.out.println("Введите текст для расшифровки");
                System.out.println(en.decrypt());  
                break;
            default:
                break;
        }
    }
    
}
